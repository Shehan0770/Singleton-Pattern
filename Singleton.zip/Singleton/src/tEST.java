public class tEST {
public static void main(String[] args) {
SingletonClass s = SingletonClass.getSingletonClass();
    System.out.println(s);

    SingletonClass s1 = SingletonClass.getSingletonClass();
    System.out.println(s1);
}
}
