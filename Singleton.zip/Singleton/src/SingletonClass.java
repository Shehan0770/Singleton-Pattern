import javax.swing.*;

public class SingletonClass {


private static volatile SingletonClass SingletonClass;


private SingletonClass() {

    if (SingletonClass != null) {

        throw new RuntimeException("please use Singleton method");

    }

}

public static SingletonClass getSingletonClass() {

    if (SingletonClass == null) {

        synchronized (SingletonClass.class) {

            if (SingletonClass == null) {

                SingletonClass = new SingletonClass();

            }

        }

    }

    return SingletonClass;

}

}



















